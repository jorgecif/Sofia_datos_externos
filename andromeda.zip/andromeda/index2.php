<!DOCTYPE html>
<html>
<head>
  <!-- Site made with Mobirise Website Builder v4.2.5, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.2.5, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="assets/images/logo2.png" type="image/x-icon">
  <meta name="description" content="Información publica de personas y empresas de Colombia, API, DIAN">
  <title>Home</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/soundcloud-plugin/style.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
</head>
<body>
<section class="menu cid-quWL99sAyA" once="menu" id="menu1-3" data-rv-view="154">

    

    <nav class="navbar navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                
                <span class="navbar-caption-wrap"><a class="navbar-caption text-white display-4" href="index.html">IDEAM Andromeda</a></span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown nav-right" data-app-modern-menu="true"><li class="nav-item">
                    <a class="nav-link link text-white display-4" href="index.html#content4-4">
                        <span class="mbri-home mbr-iconfont mbr-iconfont-btn"></span>&nbsp;¿Qué es?</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link link text-white display-4" href="admin.html"><span class="mbri-login mbr-iconfont mbr-iconfont-btn"></span>&nbsp;Login</a>
                </li></ul>
            
        </div>
    </nav>
</section>

<section class="engine"><a href="https://mobirise.co/l">bootstrap themes</a></section><section class="header11 cid-quWKS4EFrK mbr-fullscreen" id="header11-1" data-rv-view="156">

    <!-- Block parameters controls (Blue "Gear" panel) -->
    
    <!-- End block parameters -->

    
    <div class="container align-left">
        <div class="media-container-column mbr-white col-md-12">
            <h3 class="mbr-section-subtitle py-3 mbr-fonts-style display-5">
                DIRECCIÓN DE IMPUESTOS Y ADUANAS DE COLOMBIA <strong>DIAN</strong><br></h3>
            <h1 class="mbr-section-title py-3 mbr-fonts-style display-1">Accede a información por medio de nuesta <strong>API </strong>de forma rapida y sencilla<br></h1>
            <p class="mbr-text py-3 mbr-fonts-style display-5">
                Con <strong>Andromeda </strong>ahora es más facil acceder a la información que proveen empresas o instituciones colombianas.</p>
            
        </div>
    </div>

    <div class="mbr-arrow hidden-sm-down" aria-hidden="true">
        <a href="#next">
            <i class="mbri-down mbr-iconfont"></i>
        </a>
    </div>
</section>

<section class="mbr-section content4 cid-quWOt6Ek1F" id="content4-4" data-rv-view="159">

    

    <div class="container">
        <div class="media-container-row">
            <div class="title col-12 col-md-8">
                <h2 class="align-center pb-3 mbr-fonts-style display-2">
                    Andromeda</h2>
                <h3 class="mbr-section-subtitle align-center mbr-light mbr-fonts-style display-5">
                    API web para la consulta de datos publicos de empresas y personas de colombia</h3>

                <p>
                	<?php
// Activamos las sesiones para el funcionamiento de flash['']
@session_start();

require 'Slim/Slim.php';
// El framework Slim tiene definido un namespace llamado Slim
// Por eso aparece \Slim\ antes del nombre de la clase.
\Slim\Slim::registerAutoloader();

// Creamos la aplicación.
$app = new \Slim\Slim();

// Configuramos la aplicación. http://docs.slimframework.com/#Configuration-Overview
// Se puede hacer en la línea anterior con:
// $app = new \Slim\Slim(array('templates.path' => 'vistas'));
// O bien con $app->config();
$app->config(array(
    'templates.path' => 'vistas',
));

// Indicamos el tipo de contenido y condificación que devolvemos desde el framework Slim.
$app->contentType('text/html; charset=utf-8');

// Definimos conexion de la base de datos.
// Lo haremos utilizando PDO con el driver mysql.
define('BD_SERVIDOR', 'localhost');
define('BD_NOMBRE', 'dian');
define('BD_USUARIO', 'dian');
define('BD_PASSWORD', 'dian123');

// Hacemos la conexión a la base de datos con PDO.
// Para activar las collations en UTF8 podemos hacerlo al crear la conexión por PDO
// o bien una vez hecha la conexión con
// $db->exec("set names utf8");
$db = new PDO('mysql:host=' . BD_SERVIDOR . ';dbname=' . BD_NOMBRE . ';charset=utf8', BD_USUARIO, BD_PASSWORD);

////////////////////////////////////////////
// Definición de rutas en la aplicación:
// Ruta por defecto de la aplicación /
////////////////////////////////////////////

$app->get('/', function() {
	echo "Pagina de gestión API REST de mi aplicación.";
});

//******************************************************************************************************
//                                                Personas
//******************************************************************************************************
// Cuando accedamos por get a la ruta /persona ejecutará lo siguiente:
$app->get('/persona/:idpersona', function($usuarioID) use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.
	$consulta = $db->prepare("select * from usuario where id=:param1 ");
	$consulta->execute(array(':param1' => $usuarioID));
	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC)
;	// Devolvemos ese array asociativo como un string JSON.
	var_dump ($resultados);
	echo json_encode($resultados);
});





$app->get('/registraduria/:cedula', function($cedula) use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.


	$source = file_get_contents('https://wsp.registraduria.gov.co/censo/_censoResultado.php?nCedula='.$cedula.'&nCedulaH=&x=101&y=15');

	libxml_use_internal_errors( true );
	libxml_clear_errors();
	$html = new DOMDocument();
	$html->loadHTML($source);
	$xpath = new DOMXPath( $html );
	$result = array();
	// Cada TR
	$trs = $html->getElementsByTagName("tr");

	//$resultados = $trs;

	 $rows = array();

	foreach ( $trs as $tr )
	{

	        // Cada TD
	        $title = $tr->getElementsByTagName("td")->item(0)->nodeValue;
	        $value = $tr->getElementsByTagName("td")->item(1)->nodeValue;
	 
	 		$rows[$title] = $value;

	       // echo $title . "\t" . $value."\n";
	        $result[$title] = $value;
	}






	// Almacenamos los resultados en un array asociativo.
	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($rows);
});





//******************************************************************************************************
//                                                Empresas
//******************************************************************************************************








//******************************************************************************************************
//                                                Noticias
//******************************************************************************************************
//http://www.eltiempo.com/buscar?q=ecopetrol+petroleo
$app->get('/eltiempo/:nombre', function($nombre) use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.


	$source = file_get_contents('http://www.eltiempo.com/buscar?q='.$nombre);

	libxml_use_internal_errors( true );
	libxml_clear_errors();
	$html = new DOMDocument();
	$html->loadHTML($source);
	$xpath = new DOMXPath( $html );
	$result = array();
	// Cada TR
	$trs = $html->getElementsByTagName("article");

	//$resultados = $trs;

	 $rows = array();

	foreach ( $trs as $tr )
	{

	        // Cada TD
	        $img = $tr->getElementsByTagName("img");
	        $result['image'] = $img;

	        $title = $tr->getElementsByTagName("h3");	 
	 		$rows['title'] = $title;

	 		$epigraph = $tr->getElementsByTagName("a");	 
	 		$rows['epigraph'] = $epigraph;

	 		//echo "".$tr;

	}






	// Almacenamos los resultados en un array asociativo.
	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($rows);
});

function getElementsByClass(&$parentNode, $tagName, $className) {
    $nodes=array();

    $childNodeList = $parentNode->getElementsByTagName($tagName);
    for ($i = 0; $i < $childNodeList->length; $i++) {
        $temp = $childNodeList->item($i);
        if (stripos($temp->getAttribute('class'), $className) !== false) {
            $nodes[]=$temp;
        }
    }

    return $nodes;
}




//******************************************************************************************************
//                                                
//******************************************************************************************************
//******************************************************************************************************
//                                                
//******************************************************************************************************


// Cuando accedamos por get a la ruta /usuarios ejecutará lo siguiente:
$app->get('/usuarios', function() use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.
	$consulta = $db->prepare("select * from user");
	$consulta->execute();
	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);
	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});


// Accedemos por get a /usuarios/ pasando un id de usuario. 
// Por ejemplo /usuarios/veiga
// Ruta /usuarios/id
// Los parámetros en la url se definen con :parametro
// El valor del parámetro :idusuario se pasará a la función de callback como argumento
$app->get('/usuarios/:idusuario', function($usuarioID) use($db) {
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.
	// En PDO los parámetros para las consultas se pasan con :nombreparametro (casualmente 
	// coincide con el método usado por Slim).
	// No confundir con el parámetro :idusuario que si queremos usarlo tendríamos 
	// que hacerlo con la variable $usuarioID
	$consulta = $db->prepare("select * from user where id=:param1");

	// En el execute es dónde asociamos el :param1 con el valor que le toque.
	$consulta->execute(array(':param1' => $usuarioID));

	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);

	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});


//******************************************************************************************************
//                                                Empresas
//******************************************************************************************************
//------------------------------------------------------------------------------------------------------
//Obtener las empresas
$app->get('/empresas', function() use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.
	$consulta = $db->prepare("select * from empresa");
	$consulta->execute();
	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);
	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});

//******************************************************************************************************
//                                                Turnos
//******************************************************************************************************
//------------------------------------------------------------------------------------------------------
//Obtener los turnos
$app->get('/turnos', function() use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.
	$consulta = $db->prepare("select * from turno_empresa");
	$consulta->execute();
	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);
	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});
//------------------------------------------------------------------------------------------------------
//Obtener turno por cedula
//Ejmplo http://localhost/api/turnos/302
$app->get('/turnos/:idusuario', function($usuarioID) use($db) {

	$consulta = $db->prepare("select * from turno_empresa where cedula=:param1 ");

	// En el execute es dónde asociamos el :param1 con el valor que le toque.
	$consulta->execute(array(':param1' => $usuarioID));

	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);

	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});


// Pedir turno en la API REST
$app->post('/turnos', function() use($db, $app) {
	// Para acceder a los datos recibidos del formulario
	$datosform = $app->request;

	// Los datos serán accesibles de esta forma:
	// $datosform->post('apellidos')
	// Preparamos la consulta de insert.
	$consulta = $db->prepare("insert into turno_empresa(empresa_id,nombre,cedula,turno,hora) 
					values (:empresa_id,:nombre,:cedula,:turno,:hora)");

	$estado = $consulta->execute(
		   array(
			  ':empresa_id' => $datosform->post('empresa_id'),
			  ':nombre' => $datosform->post('nombre'),
			  ':cedula' => $datosform->post('cedula'),
			  ':turno' => $datosform->post('turno'),
			  ':hora' => $datosform->post('hora')
		   )
	);
	if ($estado)
		echo json_encode(array('estado' => true, 'mensaje' => 'Datos insertados correctamente.'));
	else
		echo json_encode(array('estado' => false, 'mensaje' => 'Error en el registro, intente de nuevo.'));
});
//******************************************************************************************************
//                                                Alertas
//******************************************************************************************************

//------------------------------------------------------------------------------------------------------
//Obtener las alertas
$app->get('/alertas', function() use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.
	$consulta = $db->prepare("select * from alerta");
	$consulta->execute();
	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);
	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});

//******************************************************************************************************
//                                                PQR
//******************************************************************************************************
//------------------------------------------------------------------------------------------------------
// Alta de PQR en la API REST
$app->post('/pqr', function() use($db, $app) {
	// Para acceder a los datos recibidos del formulario
	$datosform = $app->request;

	// Los datos serán accesibles de esta forma:
	// $datosform->post('apellidos')
	// Preparamos la consulta de insert.

	$consulta = $db->prepare("insert into pqr(tipo_doc,numero,nombre,apellido,telefono,direccion,ciud_dpto,dir_not,ciud_dpto_not,correo_not,autorizacion,dir_pred,ciud_dpto_pred,ciud_depto_empresa,servicio,empresa,otra_emp,cuenta_emp,asunto,anexo,estado,codigo) 
					values (:tipo_doc,:numero,:nombre,:apellido,:telefono,:direccion,:ciud_dpto,:dir_not,:ciud_dpto_not,:correo_not,:autorizacion,:dir_pred,:ciud_dpto_pred,:ciud_depto_empresa,:servicio,:empresa,:otra_emp,:cuenta_emp,:asunto,:anexo,:estado,:codigo)");

	$estado = $consulta->execute(
		   array(
			  ':tipo_doc' => $datosform->post('tipo_doc'),
			  ':numero' => $datosform->post('numero'),
			  ':nombre' => $datosform->post('nombre'),
			  ':apellido' => $datosform->post('apellido'),
			  ':telefono' => $datosform->post('telefono'),
			  ':direccion' => $datosform->post('direccion'),
			  ':ciud_dpto' => $datosform->post('ciud_dpto'),
			  ':dir_not' => $datosform->post('dir_not'),
			  ':ciud_dpto_not' => $datosform->post('ciud_dpto_not'),
			  ':correo_not' => $datosform->post('correo_not'),
			  ':autorizacion' => $datosform->post('autorizacion'),
			  ':dir_pred' => $datosform->post('dir_pred'),
			  ':ciud_dpto_pred' => $datosform->post('ciud_dpto_pred'),
			  ':ciud_depto_empresa' => $datosform->post('ciud_depto_empresa'),
			  ':servicio' => $datosform->post('servicio'),
			  ':empresa' => $datosform->post('empresa'),
			  ':otra_emp' => $datosform->post('otra_emp'),
			  ':cuenta_emp' => $datosform->post('cuenta_emp'),
			  ':asunto' => $datosform->post('asunto'),
			  ':anexo' => $datosform->post('anexo'),
			  ':estado' => $datosform->post('estado'),
			  ':codigo' => $datosform->post('codigo')
		   )
	);
	if ($estado)
		echo json_encode(array('estado' => true, 'mensaje' => 'Datos insertados correctamente.'));
	else
		echo json_encode(array('estado' => false, 'mensaje' => 'Error en el registro, intente de nuevo.'));
});
//------------------------------------------------------------------------------------------------------
//Obtener las pqr
$app->get('/pqr', function() use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.
	$consulta = $db->prepare("select * from pqr");
	$consulta->execute();
	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);
	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});

//------------------------------------------------------------------------------------------------------
// Accedemos por get a /pqr/ pasando un id de usuario. 
// Por ejemplo /pqr/101
// Ruta /pqr/id
// Los parámetros en la url se definen con :parametro
// El valor del parámetro :idusuario se pasará a la función de callback como argumento
$app->get('/pqr/:idusuario', function($usuarioID) use($db) {

	$consulta = $db->prepare("select * from pqr where numero=:param1 or codigo=:param1");

	// En el execute es dónde asociamos el :param1 con el valor que le toque.
	$consulta->execute(array(':param1' => $usuarioID));

	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);

	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});



//******************************************************************************************************
//                                        Usuario
//******************************************************************************************************

// Alta de usuarios en la API REST
$app->post('/usuarios', function() use($db, $app) {
	// Para acceder a los datos recibidos del formulario
	$datosform = $app->request;

	// Los datos serán accesibles de esta forma:
	// $datosform->post('apellidos')
	// Preparamos la consulta de insert.
	$consulta = $db->prepare("insert into user(tipo_doc,numero_doc,nombres,apellidos,telefono,direccion,ciudad_depto,direccion_not,correo,autorizacion, pass,type) 
					values (:tipo_doc,:numero_doc,:nombres,:apellidos,:telefono,:direccion,:ciudad_depto, :direccion_not,:correo,:autorizacion,:pass,:type)");

	$estado = $consulta->execute(
		   array(
			  ':tipo_doc' => $datosform->post('tipo_doc'),
			  ':numero_doc' => $datosform->post('numero_doc'),
			  ':nombres' => $datosform->post('nombres'),
			  ':apellidos' => $datosform->post('apellidos'),
			  ':telefono' => $datosform->post('telefono'),
			  ':direccion' => $datosform->post('direccion'),
			  ':ciudad_depto' => $datosform->post('ciudad_depto'),
			  ':direccion_not' => $datosform->post('direccion_not'),
			  ':correo' => $datosform->post('correo'),
			  ':autorizacion' => $datosform->post('autorizacion'),
			  ':pass' => $datosform->post('pass'),
			  ':type' => $datosform->post('type')
		   )
	);
	if ($estado)
		echo json_encode(array('estado' => true, 'mensaje' => 'Datos insertados correctamente.'));
	else
		echo json_encode(array('estado' => false, 'mensaje' => 'Error en el registro, intente de nuevo.'));
});



//------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------
//API para crear turnos
// Alta de usuarios en la API REST
/*$app->post('/usuarios', function() use($db, $app) {
	// Para acceder a los datos recibidos del formulario
	$datosform = $app->request;

	// Los datos serán accesibles de esta forma:
	// $datosform->post('apellidos')
	// Preparamos la consulta de insert.
	$consulta = $db->prepare("insert into soporte_usuarios(idusuario,nombre,apellidos,email) 
					values (:idusuario,:nombre,:apellidos,:email)");

	$estado = $consulta->execute(
		   array(
			  ':idusuario' => $datosform->post('idusuario'),
			  ':nombre' => $datosform->post('nombre'),
			  ':apellidos' => $datosform->post('apellidos'),
			  ':email' => $datosform->post('email')
		   )
	);
	if ($estado)
		echo json_encode(array('estado' => true, 'mensaje' => 'Datos insertados correctamente.'));
	else
		echo json_encode(array('estado' => false, 'mensaje' => 'Error al insertar datos en la tabla.'));
});

*/
//------------------------------------------------------------------------------------------------------


// Programamos la ruta de borrado en la API REST (DELETE)
$app->delete('/usuarios/:idusuario', function($idusuario) use($db) {
	$consulta = $db->prepare("delete from soporte_usuarios where idusuario=:id");

	$consulta->execute(array(':id' => $idusuario));

	if ($consulta->rowCount() == 1)
		echo json_encode(array('estado' => true, 'mensaje' => 'El usuario ' . $idusuario . ' ha sido borrado correctamente.'));
	else
		echo json_encode(array('estado' => false, 'mensaje' => 'ERROR: ese registro no se ha encontrado en la tabla.'));
});


// Actualización de datos de usuario (PUT)
$app->put('/usuarios/:idusuario', function($idusuario) use($db, $app) {
	// Para acceder a los datos recibidos del formulario
	$datosform = $app->request;

	// Los datos serán accesibles de esta forma:
	// $datosform->post('apellidos')
	// Preparamos la consulta de update.
	$consulta = $db->prepare("update soporte_usuarios set nombre=:nombre, apellidos=:apellidos, email=:email 
							where idusuario=:idusuario");

	$estado = $consulta->execute(
		   array(
			  ':idusuario' => $idusuario,
			  ':nombre' => $datosform->post('nombre'),
			  ':apellidos' => $datosform->post('apellidos'),
			  ':email' => $datosform->post('email')
		   )
	);

	// Si se han modificado datos...
	if ($consulta->rowCount() == 1)
		echo json_encode(array('estado' => true, 'mensaje' => 'Datos actualizados correctamente.'));
	else
		echo json_encode(array('estado' => false, 'mensaje' => 'Error al actualizar datos, datos 
						no modificados o registro no encontrado.'));
});



//////////////////////////////////////////////////////////////////////////////////////////////////
// A PARTIR DE AQUÍ ES UN EJEMPLO DE USO DE SLIM FRAMEWORK PARA CREAR UNA APLICACIÓN.
//////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
//
// EJEMPLO DE USO DEL SLIM FRAMEWORK PARA GENERAR UNA APLICACIÓN.
// 
// 
//
// Ésto no formaría parte de la API REST. Ésto sería un ejemplo de aplicación
// que podemos generar con el framework Slim.
// Aquí se muestra un ejemplo de como se generaría una página utilizando vistas.
////////////////////////////////////////////////////////////////////////////
$app->get('/listadousuarios', function() use($db, $app) {
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.
	$consulta = $db->prepare("select * from soporte_usuarios");
	// Ejecutamos la consulta (si fuera necesario se le pasan parámetros).
	$consulta->execute();

	// Ejemplo sencillo de paso de variables a una plantilla.
	/*
	  $app->render('miplantilla.php', array(
	  'name' => 'John',
	  'email' => '[email blocked]',
	  'active' => true
	  )
	  );
	 */

	// Desde dentro de la vista accederemos directamente a $resultados para gestionar su contenido.
	$app->render('listadousuarios.php', array(
	    'resultados' => $consulta->fetchAll(PDO::FETCH_ASSOC)
		   )
	);
});



// Cuando accedamos a /nuevousuario se mostrará un formulario de alta.
$app->get('/nuevousuario', function() use($app) {
	$app->render('nuevousuario.php');
})->name('altausuarios');


// Ruta que recibe los datos del formulario
$app->post('/nuevousuario', function() use($app, $db) {
	// Para acceder a los datos recibidos del formulario
	$datosform = $app->request;

	// Los datos serán accesibles de esta forma:
	// $datosform->post('apellidos')
	// Preparamos la consulta de insert.
	$consulta = $db->prepare("insert into soporte_usuarios(idusuario,nombre,apellidos,email)
				values (:idusuario,:nombre,:apellidos,:email)");

	$estado = $consulta->execute(
		   array(
			  ':idusuario' => $datosform->post('idusuario'),
			  ':nombre' => $datosform->post('nombre'),
			  ':apellidos' => $datosform->post('apellidos'),
			  ':email' => $datosform->post('email')
		   )
	);

	if ($estado)
		$app->flash('message', 'Usuario insertado correctamente.');
	else
		$app->flash('error', 'Se ha producido un error al guardar datos.');

	// Redireccionamos al formulario original para mostrar 
	// los mensajes Flash.,
	$app->redirect('nuevousuario');

	// Otra forma de hacerlo es:
	// $app->redirect($app->urlFor('altausuarios'));
});



// Otro ejemplo de aplicación en:
// http://coenraets.org/blog/2011/12/restful-services-with-jquery-php-and-the-slim-framework/
///////////////////////////////////////////////////////////////////////////////////////////////////////
// Al final de la aplicación terminamos con $app->run();
///////////////////////////////////////////////////////////////////////////////////////////////////////

$app->run();
?>
                </p>
            </div>
        </div>
    </div>
</section>

<section class="mbr-section article content11 cid-quWL28tjZg" id="content11-2" data-rv-view="161">
     

    <div class="container">
        <div class="media-container-row">
            <div class="mbr-text counter-container col-12 col-md-8 mbr-fonts-style display-7">
                <ol>
                    <li><strong>MOBILE FRIENDLY</strong> - no special actions required, all sites you make with Mobirise are mobile-friendly. You don't have to create a special mobile version of your site, it will adapt automagically. <a href="https://mobirise.com/">Try it now!</a></li>
                    <li><strong>EASY AND SIMPLE</strong> - cut down the development time with drag-and-drop website builder. Drop the blocks into the page, edit content inline and publish - no technical skills required. <a href="https://mobirise.com/">Try it now!</a></li>
                    <li><strong>UNIQUE STYLES</strong> - choose from the large selection of latest pre-made blocks - full-screen intro, bootstrap carousel, content slider, responsive image gallery with lightbox, parallax scrolling, video backgrounds, hamburger menu, sticky header and more. <a href="https://mobirise.com/">Try it now!</a></li>
                </ol>
            </div>
        </div>
    </div>
</section>

<section class="mbr-section form1 cid-quWSxdwLFT" id="form1-7" data-rv-view="162">

    

    
    <div class="container">
        <div class="media-container-column title col-12 col-lg-8 offset-lg-2">
            
            <h3 class="mbr-section-subtitle align-center mbr-light pb-3 mbr-fonts-style display-5">
                Para consultas, sugerencias o soporte escribanos</h3>
        </div>
    </div>

    <div class="container">
        <div class="media-container-column col-lg-8 offset-lg-2" data-form-type="formoid">
                <div data-form-alert="" hidden="">
                    Thanks for filling out the form!
                </div>

                <form class="mbr-form" action="https://mobirise.com/" method="post" data-form-title="Mobirise Form"><input type="hidden" data-form-email="true" value="vqtHoMLOcHwq6zbsloE5evVbtUsAkTDkBuxJlDvGO/q9rhsjl6HAw2GHXbpTGCuL+/zUYZN2YB/CnlhE6WkD610KRPrst6gkhgBqrXK1QUETt8GcR8abJ1WoI/24+olJ">
                    <div class="row row-sm-offset">
                        <div class="col-md-4 multi-horizontal" data-for="name">
                            <div class="form-group">
                                <label class="form-control-label mbr-fonts-style display-7" for="name-form1-7">Nombre</label>
                                <input type="text" class="form-control" name="name" data-form-field="Name" required="" id="name-form1-7">
                            </div>
                        </div>
                        <div class="col-md-4 multi-horizontal" data-for="email">
                            <div class="form-group">
                                <label class="form-control-label mbr-fonts-style display-7" for="email-form1-7">Correo</label>
                                <input type="email" class="form-control" name="email" data-form-field="Email" required="" id="email-form1-7">
                            </div>
                        </div>
                        <div class="col-md-4 multi-horizontal" data-for="phone">
                            <div class="form-group">
                                <label class="form-control-label mbr-fonts-style display-7" for="phone-form1-7">Teléfono</label>
                                <input type="tel" class="form-control" name="phone" data-form-field="Phone" id="phone-form1-7">
                            </div>
                        </div>
                    </div>
                    <div class="form-group" data-for="message">
                        <label class="form-control-label mbr-fonts-style display-7" for="message-form1-7">Mensaje</label>
                        <textarea type="text" class="form-control" name="message" rows="7" data-form-field="Message" id="message-form1-7"></textarea>
                    </div>

                    <span class="input-group-btn"><button href="" type="submit" class="btn btn-form btn-primary display-4">Enviar</button></span>
                </form>
        </div>
    </div>
</section>

<section once="" class="cid-quWKLyGHOS" id="footer6-0" data-rv-view="165">

    

    

    <div class="container">
        <div class="media-container-row align-center mbr-white">
            <div class="col-12">
                <p class="mbr-text mb-0 mbr-fonts-style display-7">
                    © Copyright 2017 DIAN- All Rights Reserved power by MINTIC</p>
            </div>
        </div>
    </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/dropdown/js/script.min.js"></script>
  <script src="assets/touch-swipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/smooth-scroll/smooth-scroll.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/formoid/formoid.min.js"></script>
  
  
</body>
</html>