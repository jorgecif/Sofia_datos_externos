<?php
$page_title = "n/a";
$meta_descr = "n/a";
        
if ($handle = fopen("http://www.programacion.net", "r")) {
        $content = '';
        while (!feof($handle)) {
                $part = fread($handle, 1024);
                $content .= $part;
                if (preg_match('/</head>/', $part)) break;
        }
        fclose($handle);
        $lines = preg_split('/r?n|r/', $content);
        $result = true;
        $is_title = false;
        $is_descr = false;
        foreach ($lines as $val) {
                if (preg_match('/<title>(.*)</title>/', $val, $title)) {
                        $page_title = $title[1];
                        $is_title = true;
                } 
                if (preg_match('/<meta name="description" content="(.*)"s?/?>/', $val, $descr)) {
                        $meta_descr = $descr[1];
                        $is_descr = true;
                }
                if ($is_title && $is_descr) break;
        }
}