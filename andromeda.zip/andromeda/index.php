<meta charset="utf-8">
<?php
// Activamos las sesiones para el funcionamiento de flash['']
@session_start();

require 'Slim/Slim.php';
// El framework Slim tiene definido un namespace llamado Slim
// Por eso aparece \Slim\ antes del nombre de la clase.
\Slim\Slim::registerAutoloader();

// Creamos la aplicación.
$app = new \Slim\Slim();

// Configuramos la aplicación. http://docs.slimframework.com/#Configuration-Overview
// Se puede hacer en la línea anterior con:
// $app = new \Slim\Slim(array('templates.path' => 'vistas'));
// O bien con $app->config();
$app->config(array(
    'templates.path' => 'vistas',
));

// Indicamos el tipo de contenido y condificación que devolvemos desde el framework Slim.
$app->contentType('text/html; charset=utf-8');

// Definimos conexion de la base de datos.
// Lo haremos utilizando PDO con el driver mysql.
define('BD_SERVIDOR', 'localhost');
define('BD_NOMBRE', 'dian');
define('BD_USUARIO', 'dian');
define('BD_PASSWORD', 'dian123');

// Hacemos la conexión a la base de datos con PDO.
// Para activar las collations en UTF8 podemos hacerlo al crear la conexión por PDO
// o bien una vez hecha la conexión con
// $db->exec("set names utf8");

$db= "";

//$db = new PDO('mysql:host=' . BD_SERVIDOR . ';dbname=' . BD_NOMBRE . ';charset=utf8', BD_USUARIO, BD_PASSWORD);

////////////////////////////////////////////
// Definición de rutas en la aplicación:
// Ruta por defecto de la aplicación /
////////////////////////////////////////////

$app->get('/', function() {
	conhtml("ANDROMEDA by MINTIC");
	//echo ;
});



function utf16_2_utf8 ($nowytekst) {
	/*
	    $nowytekst = str_replace('%u0104','Ą',$nowytekst);    //Ą
        $nowytekst = str_replace('%u0106','Ć',$nowytekst);    //Ć
        $nowytekst = str_replace('%u0118','Ę',$nowytekst);    //Ę
        $nowytekst = str_replace('%u0141','Ł',$nowytekst);    //Ł
        $nowytekst = str_replace('%u0143','Ń',$nowytekst);    //Ń
        $nowytekst = str_replace('%u00D3','Ó',$nowytekst);    //Ó
        $nowytekst = str_replace('%u015A','Ś',$nowytekst);    //Ś
        $nowytekst = str_replace('%u0179','Ź',$nowytekst);    //Ź
        $nowytekst = str_replace('%u017B','Ż',$nowytekst);    //Ż
      
        $nowytekst = str_replace('%u0105','ą',$nowytekst);    //ą
        $nowytekst = str_replace('%u0107','ć',$nowytekst);    //ć
        $nowytekst = str_replace('%u0119','ę',$nowytekst);    //ę
        $nowytekst = str_replace('%u0142','ł',$nowytekst);    //ł
        $nowytekst = str_replace('%u0144','ń',$nowytekst);    //ń
        $nowytekst = str_replace('%u00F3','ó',$nowytekst);    //ó
        $nowytekst = str_replace('%u015B','ś',$nowytekst);    //ś
        $nowytekst = str_replace('%u017A','ź',$nowytekst);    //ź
        $nowytekst = str_replace('%u017C','ż',$nowytekst);    //ż	
	*/
		
		
		$nowytekst = str_replace('\u00d1','Ñ',$nowytekst);    //Ñ
		
		
        $nowytekst = str_replace('\u00f3','ó',$nowytekst);    //ó
        $nowytekst = str_replace('%u017C','ż',$nowytekst);    //ż
		
   return ($nowytekst);
   }    
//******************************************************************************************************
//                                                Personas
//******************************************************************************************************
//------------------------------------------------------------------------------------------------------
//
$app->get('/registraduria/:cedula', function($cedula) use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.


	$source = file_get_contents('https://wsp.registraduria.gov.co/censo/_censoResultado.php?nCedula='.$cedula.'&nCedulaH=&x=101&y=15');

	libxml_use_internal_errors( true );
	libxml_clear_errors();
	$html = new DOMDocument();
	$html->loadHTML($source);
	$xpath = new DOMXPath( $html );
	$result = array();
	// Cada TR
	$trs = $html->getElementsByTagName("tr");

	//$resultados = $trs;

	 $rows = array();

	foreach ( $trs as $tr )
	{

	        // Cada TD
	        $title = $tr->getElementsByTagName("td")->item(0)->nodeValue;
	        $value = $tr->getElementsByTagName("td")->item(1)->nodeValue;
	 
	 		$rows[$title] = $value;

	       // echo $title . "\t" . $value."\n";
	        $result[$title] = $value;
	}

	// Almacenamos los resultados en un array asociativo.
	// Devolvemos ese array asociativo como un string JSON.
	echo utf16_2_utf8(json_encode($rows));
});
//-------------------------------------------------------------------------------------------------------
//El usuario debe escribir la cedula de la persona a consultar
$app->get('/procuraduriaCED/:cedula', function($cedula) use($db) {

	$source = 'https://www.procuraduria.gov.co/CertWEB/Certificado.aspx?tpo=1';
	$context = stream_context_create(array(
		'http' => array(
      	'method'  => 'POST',
      	'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
      	'content' => http_build_query(array('__EVENTTARGET' => '','__EVENTARGUMENT' => '','__VIEWSTATE' => '/wEPDwUJLTU5NTU5MDcyDxYCHgpJZFByZWd1bnRhBQE4FgICAw9kFgoCAQ8PFgIeBFRleHQFGENvbnN1bHRhIGRlIGFudGVjZWRlbnRlc2RkAg0PFgIeB1Zpc2libGVoFgQCAQ9kFgICAQ8QZGQWAWZkAgMPZBYCAgEPEGRkFgBkAg8PDxYCHwEFL8K/TsO6bWVybyBkZSBjb2xvcmVzIGVuIGxhIGJhbmRlcmEgZGUgQ29sb21iaWE/ZGQCGA8PFgIfAmgWAh4Hb25jbGljawUeJCgnI3R4dENhcHRjaGEnKS5yZWFscGVyc29uKCk7ZAIkDw8WAh8BBQdWLjAuMC40ZGQYAQUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFgEFDEltYWdlQnV0dG9uMSx6uLoEroUcq6HoeBpBv/283GQX','__VIEWSTATEGENERATOR' => 'D8335CE7','__EVENTVALIDATION' => '/wEWCgKRluXOAQL8kK+TAQLwkOOQAQLvkOOQAQLxkOOQAQL0kOOQAQK8zP8SAtLCmdMIAsimk6ECApWrsq8ITJ8mWGUxMaoVSN68dXhPhuvITwk=','ddlTipoID' => '1','txtNumID' => $cedula,'txtRespuestaPregunta' => '3','btnConsultar' => 'Consultar'))
    	),
 	 ));
	$return = file_get_contents($source, false, $context);

	//echo $return;

	//echo getHTMLByID('divSec', $return);



	libxml_use_internal_errors( true );
	libxml_clear_errors();
	$html = new DOMDocument();
	$html->loadHTML(getHTMLByID('divSec', $return));
	$xpath = new DOMXPath( $html );
	$result = array();
	
	$nombre='';
	$serials = $html->getElementsByTagName('span') ;
	foreach($serials as $serial) {
	  $nombre= $nombre." ".$serial->nodeValue ;    
	}

	$antecedente='';
	$serials = $html->getElementsByTagName('h2') ;
	foreach($serials as $serial) {
	  $antecedente= $serial->nodeValue ;    
	}



	 $rows = array();

	 $rows['nombre'] = $nombre;
	 $rows['antecedente'] = $antecedente;


	echo utf16_2_utf8(json_encode($rows));

	
});


function getHTMLByID($id, $html) {
    $dom = new DOMDocument;
    libxml_use_internal_errors(true);
    $dom->loadHTML($html);
    $node = $dom->getElementById($id);
    if ($node) {
         return $dom->saveHTML($node);
         //return json_encode($dom);
    }
    return FALSE;
}
//-------------------------------------------------------------------------------------------------------
//
$app->get('/licencia/:cedula', function($cedula) use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.




	//include('httpful.phar');
	include('./httpful.phar');


	$url = "http://web.mintransporte.gov.co/Consultas/transito/Informe23122010.asp?encoding=utf-8";


	$response = \Httpful\Request::post($url)

	//header('Content-Type: text/html; charset=utf-8')
	
		->withoutStrictSsl() // Ease up on some of the SSL checks
	//	->expectsJson() // Expect HTML responses
		->expectsXml()
		->body('doc=C&LICIDENT='.$cedula, Httpful\Mime::FORM)
		//->xExampleHeader('Content-Type: text/html; charset=utf-8')
		//->addHeader('Content-Type: text/html; charset=utf-8')    // Or use the addHeader method
		->send();


	//$source = file_get_contents($response);

	echo utf8_encode($response);
	//var_dump($source);
	die();


/*

	libxml_use_internal_errors( true );
	libxml_clear_errors();
	$html = new DOMDocument();
	$html->loadHTML($source);
	$xpath = new DOMXPath( $html );
	$result = array();
	// Cada TR
	$trs = $html->getElementsByTagName("tr");

	//$resultados = $trs;

	 $rows = array();

	foreach ( $trs as $tr )
	{

	        // Cada TD
	        $title = $tr->getElementsByTagName("td")->item(0)->nodeValue;
	        $value = $tr->getElementsByTagName("td")->item(1)->nodeValue;
	 
	 		$rows[$title] = $value;

	       // echo $title . "\t" . $value."\n";
	        $result[$title] = $value;
	}

	// Almacenamos los resultados en un array asociativo.
	// Devolvemos ese array asociativo como un string JSON.
	echo utf16_2_utf8(json_encode($rows));
});


$response = \Httpful\Request::post($uri)
    ->body('<xml><name>Value</name></xml>')
    ->sendsXml()
    ->send();

*/
});
//-------------------------------------------------------------------------------------------------------
//
$app->get('/sisben_ced/:cedula', function($cedula) use($db) {

	$source = 'https://wssisbenconsulta.sisben.gov.co/dnp_sisbenconsulta/dnp_sisben_consulta.aspx';
	$context = stream_context_create(array(
		'http' => array(
      	'method'  => 'POST',
      	'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
      	'content' => http_build_query(array('__EVENTTARGET'=>'','__EVENTARGUMENT'=>'','__VIEWSTATE'=>'h9uS6+c5tB4sc/iiGyyjb+1Tb/flSETe7u2xZqLz6rJeuvyFJgGXNVPGAaWgLd9TOQFup6sM4AOyT5xKHipfOGV1lpykLrKvGAys9alWpnhXvJjgpLoqUlipCjOZVXA3g2A+gp3CP4MxuI3PCzlJL7Tn/i3QJaSi9VXQER1kxHlqKjhztz+fe5kYxA7Rb62oWxQQYQkeH1wZF6tznyb5cUh35R9wCU3CPyoN8M0/jDzmhPtFHRFhMUjsU7bw/lnspzUZTl+tIFW3mw10sV1gGV3tFfDhbHG/7yFl+YmT2jdxAoypjelqYQHqXh83pYJoLHcFAdc20j6uN/S0q2ejlg+yeonlqbG3XNgCVJy0cjaDAJ2+1iGVlyfkrQMG75boF66H775qB7aA7mrodkP5gejDlzeAWH1M80gukDgcHkfUwKNlxM4unYtCUvciQUft5QArfPwFMYiQYtaZs8CnX+fJPHrzimuOcf7ha1+27yOHuV2Zyy6f8gKswXOTpOJPCoMsqdXhndXijCw8jSmbQA9drjQa7L+EWdlfE1F9VMIbEZiz6LRqzufMO9IxgOOs0eHy9FXGVhyQYgt8VY41KxH4Y4kwYpN1eK4ADDMfefEwL0kfQXg4DrMI5vie9oD4qCHHzIs4EIIuY5GtxIzu9oV7KWqfwj6CoTX7ViZEHTKfUPse9gO5TZPYb6m5CQJn2z/Cdcnkiqm0Z0AXwfY4DS5HXe3RaZbNd1InkN3yu9dvTFWIVaI3/FPWDJspjmUPOlidluAfc4ot+h8wx7zzoK+nLVBENFyUSpkCb6d75GXRmopJjhrtsYuUc18uVnwthnFpflIEK2kKzstukLdlTEbH9Cok7K9LTmIz+9BT9CgZbu9aj/AYnRaj8B69kjSC1ixq3ng00wUZYk77Lbk4MmcBdocK/KsLNBlMEEFaA4eT1bAsd37KDJ4bHF4IM98xjN5Ez1+n4WrCfgJfj3Q10zE0neTLJc2fQYwqb7RuZP9Qkdt8x1BFEHJdNJS7XLiPCWcdj2yJKeUpwqDxbllNtVGC94gDInZ3cImtVdNYfG+BDB9yumglNZbx3G16gzqT7E2WGQHEvey/uzP4wzHnUSaVsUihOtg2Kj5OY+ckIQEjIZ9EkbAKn42plTV8LMzUePGLcmue69c2oq4DK6xxRrym0Rkr37R7jxZk/RCO1BBJqdVsZ93BcdNXr9QoSk/g0W35kB/TyJfuJQK90/3JPDngmntnNi7nR5C6JDZQ3pd6q8rJZQo2Ys721G5ICVA+z7J9V999v91Fw+4ofDiDeAsztKBHUSdp867hovRhCpG/48PVBOYe2vuhcV0+ycG/pcIlA97EwTdIefLkX0/FijNV6bmbyYCYQEnVOZ+s/lfcQoQ1/E2Qcuz/DDeT1WnULAzu6fsocEn8PB2YbNcbUHi4vJJe9bZwiHckDWThQKmlQvs63wW3s3z+MoflU5V0bRL7ABOnoAZL786DYUdrxJ3Gx/duPqxLxk5ZB+AlydXpCShw1t5WEHNZWJ5EFSsUOSuxiUgrRDwbkRI6eXmV04fjhVLO4pYGGh7l5sWiRRd1+dGZ+tl4ZbuZjqzBTbYBPHG9zRJG4PPIAEKK/fS298XmjO094ihbeI0OkpoR7XhRKPm5Zn34vzBpmUK/Cq0g4+ZxBqCfkhB6neBPRhJy6y/niRMmWDX1+ekS+tKXXFSlVmzwtcb2YvIoh+oAO36i6uW/iW+SkprYnquUnswdGMIzPqM01npxNAqqt9KPC9rtxyk/IvLZ1aVKK1PN4zKBEx6N5fW/xv496QuJ3Q2bflkKgBo/HM/y9lzam0Jk6INrYhi2H2a5XLyYLgPOQPArsMyQa3iQwlSGX/AXtbcXXQY9lQ/7Z96g5ZvVq9jmBSajgQIfJQyNvbSc54D83eKrewBamcRjEoFB8dBLoVMVcY8uYrgqoIg6thlQ6ZuxXX/+Soj9JmbIFU7V/4O5zwGBb9JT4l382rWceCYqFrQj2WZrBz82duaGSGHE5xNl9ncu8pa9vsly1GVm8p9ARfzHEYM4s30JMwLdmTDOaiOCVQTrMtGKx67sHYWjCoM1KG3wcwOr9R49N8wne1a9qih2DoQPSH2FLKpqWzt5o+t7RPinBFBd1GV/M+vp8S0Sczq6ya2BEvZB0Kupi3M+dwr8WXq2175d1oBO+y7DnLWq1pWtpnoJ+1SaZYx5durlBU3FDCoemeOLXWHXot2wpQr1ocynI/HUTIsOi5QLKXbkl2RE9iNWfFOySq0gb2nGgNcMT1Oy3r4UW+l/4KphP5Z1goWllpmydXWJAji7VOSr4HQ9smwPAvRWxbQcis9Q+5Os6Te/RoWDTw1f+ApPeYJiwevSLKNpYH0QR/S5ulLGtDaAAv6ajJmNA2sMF8CrFOJtId3+rEkB2+V0xI9vf+iNxollMgs9Y8qDGMBfz8IDznUuQe+3lGM+zfcA9Z7EmWxjmmKrS0u/lHq3V1Q4ynq5HoBg+kgi8nRi14i7Cd9hXg0dap/RZC3WrpjR0QF7DqeSsb3WWU/ZGRF93E+uZFlERJ+tyLUhnF6liOg6jMdTP0h6gSUqGyzj8RME7w9htKFeorjHLOAD0ieNPC9uY3OP1e4XWPMnGcctGjqUglUgOEpk92HUchaY8jwTYFMzmnQ06FJCy2uh7E6D24r+5O6WIwvue06iMnzQzrHokmreUA==','__VIEWSTATEGENERATOR'=>'2AB62757','__VIEWSTATEENCRYPTED'=>'','__EVENTVALIDATION'=>'B1po+TB4eH6W5wzjLp+DAB2vChpVXr017VHoELzU/qqwDyW3An/RkJzCcswkkDrG7iyrnQ8jG5JuSu0SdeSGItfsT/msl+i4EtnPpGdANGscZAMJjq8n12NaQTCLd8zdCDRqZ/k6DemPrYagX3KFkuJW+fyN9xi1X0hKwqN9JgvFv+VVbFVI0fue7bgCl2Rlo+oAs/wSSCg2j1yfMdbsZcq5eU/H81ygTWEM3jqKRLn4R+RINf9qAHa/X9xsIZfZtzYezMkgOdN/oaZvOBOza4G0Ah8sNyijMrJBSFrdo5J1rDZE4DSA80gGHb3t1OxK','ddlTipoDocumento'=>'1','tboxNumeroDocumento'=>$cedula,'btnConsultar'=>'Consultar'))
    	),
 	 ));
	$return = file_get_contents($source, false, $context);

	echo getHTMLByID('panelSiResultado', $return);
	//echo $return;

	//conhtml($return);
});

//******************************************************************************************************
//                                                Empresas
//******************************************************************************************************
//-------------------------------------------------------------------------------------------------------
//Resive el nombre de la empresa
$app->get('/rues_name/:name', function($name) use($db) {

	$source = 'http://www.rues.org.co/RM/ConsultaNombre_json';
	$context = stream_context_create(array(
		'http' => array(
      	'method'  => 'POST',
      	'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
      	'content' => http_build_query(array('txtNombre' => $name))
    	),
 	 ));
	$return = file_get_contents($source, false, $context);
	echo $return;

	//conhtml($return);
});
//-------------------------------------------------------------------------------------------------------
//Recibe el nit de la empresa
$app->get('/rues_nit/:nit', function($nit) use($db) {

	$source = 'http://www.rues.org.co/RM/ConsultaNIT_json';
	$context = stream_context_create(array(
		'http' => array(
      	'method'  => 'POST',
      	'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
      	'content' => http_build_query(array('txtNIT' => $nit))
    	),
 	 ));
	$return = file_get_contents($source, false, $context);
	echo $return;
});
//******************************************************************************************************
//                                                Imprimir bonito                                       
//******************************************************************************************************


function conhtml($texto)
{?>
    <!DOCTYPE html>
    <html>
    <head>
    	<title>Andromeda</title>
    	<style>
    	body{
    		background-color: #131313;
    		text: #ffffff;
            
            font-size:20px;
    	}
    	p{
    		color: #ecf0f1;
    	}

        </style>
    </head>
    <body text="#ffffff">
    	<?php
    	echo $texto;
    	?>
    
    </body>
    </html>

<?php    
}
//******************************************************************************************************
//                                                Redes sociales
//******************************************************************************************************

function fb_fan_count( $fb_page ){
    $data = json_decode(file_get_contents('http://graph.facebook.com/' . $fb_page.''));
    echo $data->likes;
}

function sallute(){
	require_once __DIR__ . '/Facebook/autoload.php'; // change path as needed

$fb = new \Facebook\Facebook([
  'app_id' => '144364866188854',
  'app_secret' => '0b1615e949ae4c85fa4adca6566ac840',
  'default_graph_version' => 'v2.10',
  //'default_access_token' => '{access-token}', // optional
]);

// Use one of the helper classes to get a Facebook\Authentication\AccessToken entity.
//   $helper = $fb->getRedirectLoginHelper();
//   $helper = $fb->getJavaScriptHelper();
//   $helper = $fb->getCanvasHelper();
//   $helper = $fb->getPageTabHelper();

try {
  // Get the \Facebook\GraphNodes\GraphUser object for the current user.
  // If you provided a 'default_access_token', the '{access-token}' is optional.
  $response = $fb->get('/me', '{access-token}');
} catch(\Facebook\Exceptions\FacebookResponseException $e) {
  // When Graph returns an error
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch(\Facebook\Exceptions\FacebookSDKException $e) {
  // When validation fails or other local issues
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}

$me = $response->getGraphUser();
echo 'Logged in as ' . $me->getName();
}
//sallute();
 
//fb_fan_count('enespanol');

function likes(){
	try {
  // Returns a `Facebook\FacebookResponse` object
  $response = $fb->get(
    '/{1648178460}/likes',
    '{EAACDTJCRNjYBAPNJQgwvC9ZCow63pVHIL5OeyqLZBjqxBA7PmYhGsCiXAVgUElZAQVnWMCr4fRKvo1LtqRxsirydA3vXPK8hyGLjCATzPKgQTHnHk3GmMlZACMnkj2D83aEFWTMWKd7XTWxRJrgHHMIA3Q7GZBGtZAee5B5whknNcrN0StG6u5JvCvLlHPxmcZD}'
  );
} catch(Facebook\Exceptions\FacebookResponseException $e) {
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch(Facebook\Exceptions\FacebookSDKException $e) {
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}
}
//likes();


function twitter(){
	require_once('twitteroauth/twitteroauth.php');
$connection = new TwitterOAuth('9c6RiPhWKta8MtmegTh6CWKoa', 'YrMKgr9OSvP2L6cqg608GOarnRSCfH8nGZch9TsEN6V9JcpXIY', '438927474-1xPRxLhL21QVE8fyF1iWoIskcKxWG9tua9x0ewYs', 'Dh0QinESVDk08lpHTnWyJuCurUw4MsiGK0VxaJLX1xtcF');

// Empty array that will be used to store followers.
$profiles = array();
// Get the ids of all followers.
$ids = $connection->get('followers/ids');
// Chunk the ids in to arrays of 100.
$ids_arrays = array_chunk($ids, 100);

// Loop through each array of 100 ids.
foreach($ids_arrays as $implode) {
  // Perform a lookup for each chunk of 100 ids.
  $results = $connection->get('users/lookup', array('ciberscanner' => implode(',', $implode)));
  // Loop through each profile result.
  foreach($results as $profile) {
    // Use screen_name as key for $profiles array.
    $profiles[$profile->screen_name] = $profile;
  }
}

// Array of user objects.
var_dump($profiles);
}

function twitterxxx(){

}

//twitterxxx();


//******************************************************************************************************
//                                                Twitter
//******************************************************************************************************

class Twitter{

    function getTweets($user){
        ini_set('display_errors', 1);
        require_once('Twitter/TwitterAPIExchange.php');

        $settings = array(
            'oauth_access_token' => "438927474-1xPRxLhL21QVE8fyF1iWoIskcKxWG9tua9x0ewYs",
            'oauth_access_token_secret' => "Dh0QinESVDk08lpHTnWyJuCurUw4MsiGK0VxaJLX1xtcF",
            'consumer_key' => "9c6RiPhWKta8MtmegTh6CWKoa",
            'consumer_secret' => "YrMKgr9OSvP2L6cqg608GOarnRSCfH8nGZch9TsEN6V9JcpXIY"
        );

        $url = 'https://api.twitter.com/1.1/statuses/user_timeline.json';
        $getfield = '?screen_name='.$user.'&count=100';        
        $requestMethod = 'GET';
        $twitter = new TwitterAPIExchange($settings);
        $json =  $twitter->setGetfield($getfield)
                     ->buildOauth($url, $requestMethod)
                     ->performRequest(true, array(CURLOPT_CAINFO => dirname(__FILE__) . '/cacert.pem'));
        return $json;

    }

    function getFollowers($user){
    	ini_set('display_errors', 1);
        require_once('Twitter/TwitterAPIExchange.php');

        $settings = array(
            'oauth_access_token' => "438927474-1xPRxLhL21QVE8fyF1iWoIskcKxWG9tua9x0ewYs",
            'oauth_access_token_secret' => "Dh0QinESVDk08lpHTnWyJuCurUw4MsiGK0VxaJLX1xtcF",
            'consumer_key' => "9c6RiPhWKta8MtmegTh6CWKoa",
            'consumer_secret' => "YrMKgr9OSvP2L6cqg608GOarnRSCfH8nGZch9TsEN6V9JcpXIY"
        );

        $url = 'https://api.twitter.com/1.1/followers/list.json?cursor=-1&screen_name=twitterdev&skip_status=true&include_user_entities=false';
        $getfield = '?screen_name='.$user.'&count=100';        
        $requestMethod = 'GET';
        $twitter = new TwitterAPIExchange($settings);
        $json =  $twitter->setGetfield($getfield)
                     ->buildOauth($url, $requestMethod)
                     ->performRequest(true, array(CURLOPT_CAINFO => dirname(__FILE__) . '/cacert.pem'));
        return $json;


    }

    function getFollowers2($user){
    	$tw_username = $user; 
		$data = file_get_contents('https://cdn.syndication.twimg.com/widgets/followbutton/info.json?screen_names='.$tw_username); 
		$parsed =  json_decode($data,true);
		$tw_followers =  $parsed[0]['followers_count'];

		return $tw_followers;
    }

    function getArrayTweets($jsonraw){
        $rawdata = "";
        $json = json_decode($jsonraw);
        $num_items = count($json);
        for($i=0; $i<$num_items; $i++){

            $user = $json[$i];

            $fecha = $user->created_at;
            $url_imagen = $user->user->profile_image_url;
            $screen_name = $user->user->screen_name;
            $tweet = $user->text;

            $imagen = "<a href='https://twitter.com/".$screen_name."' target=_blank><img src=".$url_imagen."></img></a>";
            $name = "<a href='https://twitter.com/".$screen_name."' target=_blank>@".$screen_name."</a>";

            $rawdata[$i][0]=$fecha;
            $rawdata[$i]["FECHA"]=$fecha;
            $rawdata[$i][1]=$imagen;
            $rawdata[$i]["imagen"]=$imagen;
            $rawdata[$i][2]=$name;
            $rawdata[$i]["screen_name"]=$name;
            $rawdata[$i][3]=$tweet;
            $rawdata[$i]["tweet"]=$tweet;
        }
        return $rawdata;
    }

    function displayTable($rawdata){

        //DIBUJAMOS LA TABLA
        echo '<table border=1>';
        $columnas = count($rawdata[0])/2;
        //echo $columnas;
        $filas = count($rawdata);
        //echo "<br>".$filas."<br>";
        //Añadimos los titulos

        for($i=1;$i<count($rawdata[0]);$i=$i+2){
            next($rawdata[0]);
            echo "<th><b>".key($rawdata[0])."</b></th>";
            next($rawdata[0]);
        }
        for($i=0;$i<$filas;$i++){
            echo "<tr>";
            for($j=0;$j<$columnas;$j++){
                echo "<td>".$rawdata[$i][$j]."</td>";

            }
            echo "</tr>";
        }       
        echo '</table>';
    }
}

$app->get('/twitter/:nombre', function($nombre) use($db){

$twitterObject = new Twitter();
$jsonraw =  $twitterObject->getTweets($nombre);

echo 'seguidores: '.$twitterObject->getFollowers2($nombre);

$rawdata =  $twitterObject->getArrayTweets($jsonraw);
$twitterObject->displayTable($rawdata);

});








//_--------------------//_----------------//_----------------------//---------------------//_-----------


$app->get('/tfollowers/:nombre',function($nombre) use($db){
	//https://api.twitter.com/1.1/followers/list.json?cursor=-1&screen_name=twitterdev&skip_status=true&include_user_entities=false


});





//******************************************************************************************************
//                                                Google Noticias
//******************************************************************************************************
$app->get('/google/:nombre', function($nombre) use($db){


include("simple_html_dom.php");


$in = $nombre;
$in = str_replace(' ','+',$in); // space is a +
//$url  = 'http://www.google.com/search?hl=en&tbo=d&site=&source=hp&q='.$in.'&oq='.$in.'';

$url = 'https://www.google.com/search?client=firefox-b-ab&dcr=0&biw=1600&bih=538&tbm=nws&ei=s_MUWvuZI6mcjwT577WYBw&q='.$in.'&oq='.$in.'';

//print $url."<br>";

$html = file_get_html($url);

$i=0;
$linkObjs = $html->find('h3.r a'); 
foreach ($linkObjs as $linkObj) {
    $title = trim($linkObj->plaintext);
    $link  = trim($linkObj->href);

    // if it is not a direct link but url reference found inside it, then extract
    if (!preg_match('/^https?/', $link) && preg_match('/q=(.+)&amp;sa=/U', $link, $matches) && preg_match('/^https?/', $matches[1])) {
        $link = $matches[1];
    } else if (!preg_match('/^https?/', $link)) { // skip if it is not a valid link
        continue;
    }

    $descr = $html->find('.st',$i); // description is not a child element of H3 thereforce we use a counter and recheck.
    $i++;   
    echo '<p>Titulo: ' . utf8_encode ($title) . '<br />';
    echo 'Link: ' . $link . '<br />';
    echo 'Descripcion: ' . utf8_encode ($descr) . '</p>';
}


});

//----------------------------------------------------------------------------------------------------------------------------------------------

$app->get('/google_redes/:nombre', function($nombre) use($db){
include("simple_html_dom.php");

$in = $nombre;
$in = str_replace(' ','+',$in); // space is a +

$url = 'https://www.google.com/search?newwindow=1&client=firefox-b-ab&dcr=0&ei=tz8XWteMJM2H_QaIi6PwBQ&q=page+'.$in.'&oq=page+'.$in;

$html = file_get_html($url);

$i=0;
$linkObjs = $html->find('h3.r a'); 
foreach ($linkObjs as $linkObj) {
    $title = trim($linkObj->plaintext);
    $link  = trim($linkObj->href);

    // if it is not a direct link but url reference found inside it, then extract
    if (!preg_match('/^https?/', $link) && preg_match('/q=(.+)&amp;sa=/U', $link, $matches) && preg_match('/^https?/', $matches[1])) {
        $link = $matches[1];
    } else if (!preg_match('/^https?/', $link)) { // skip if it is not a valid link
        continue;
    }

    $descr = $html->find('.st',$i); // description is not a child element of H3 thereforce we use a counter and recheck.
    $i++;

    if(strpos($link,'twitter')!== false ){
    	echo 'Link: ' . $link . '<br />';
    } else if(strpos($link,'facebook')!== false ){
    	echo 'Link: ' . $link . '<br />';
    }
}


});

//******************************************************************************************************
//                                                Periodicos
//******************************************************************************************************
//--------------------------------------------- El Tiempo ----------------------------------------------


$app->get('/elespectador/:nombre', function($nombre) use($db){
	// https://www.elespectador.com/search/mamoncillo

	$dom = new DOMDocument('1.0', 'utf-8');
$dom->loadHTML($html);
$content_node=$dom->getElementById("content_node");

$div_a_class_nodes=getElementsByClass($content_node, 'div', 'a');


} );



//http://www.eltiempo.com/buscar?q=ecopetrol+petroleo
$app->get('/eltiempo/:nombre', function($nombre) use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.


	$source = file_get_contents('http://www.eltiempo.com/buscar?q='.$nombre);

	libxml_use_internal_errors( true );
	libxml_clear_errors();
	$html = new DOMDocument();
	$html->loadHTML($source);
	$xpath = new DOMXPath( $html );
	$result = array();
	// Cada TR
	$trs = $html->getElementsByTagName("article");

	//$resultados = $trs;

	 $rows = array();

	 $items = $html->getElementsByTagName('article');

	 for ($i = 0; $i < $items->length; $i++)
        echo $items->item($i)->nodeValue . "<br/>";

	/*foreach ( $trs as $tr )
	{

	        // Cada TD
	        $img = $tr->getElementsByTagName("img");
	        $rows['image'] = $img;

	        $title = $tr->getElementsByTagName("h3");	 
	 		$rows['title'] = $title;

	 		$epigraph = $tr->getElementsByTagName("a");	 
	 		$rows['epigraph'] = $epigraph;

	 		//echo "".$tr;


	}
*/





	// Almacenamos los resultados en un array asociativo.
	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($rows);
});

function getElementsByClass(&$parentNode, $tagName, $className) {
    $nodes=array();

    $childNodeList = $parentNode->getElementsByTagName($tagName);
    for ($i = 0; $i < $childNodeList->length; $i++) {
        $temp = $childNodeList->item($i);
        if (stripos($temp->getAttribute('class'), $className) !== false) {
            $nodes[]=$temp;
        }
    }

    return $nodes;
}




//******************************************************************************************************
//                                                
//******************************************************************************************************
//******************************************************************************************************
//                                                
//******************************************************************************************************


// Cuando accedamos por get a la ruta /usuarios ejecutará lo siguiente:
$app->get('/usuarios', function() use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.
	$consulta = $db->prepare("select * from user");
	$consulta->execute();
	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);
	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});


// Accedemos por get a /usuarios/ pasando un id de usuario. 
// Por ejemplo /usuarios/veiga
// Ruta /usuarios/id
// Los parámetros en la url se definen con :parametro
// El valor del parámetro :idusuario se pasará a la función de callback como argumento
$app->get('/usuarios/:idusuario', function($usuarioID) use($db) {
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.
	// En PDO los parámetros para las consultas se pasan con :nombreparametro (casualmente 
	// coincide con el método usado por Slim).
	// No confundir con el parámetro :idusuario que si queremos usarlo tendríamos 
	// que hacerlo con la variable $usuarioID
	$consulta = $db->prepare("select * from user where id=:param1");

	// En el execute es dónde asociamos el :param1 con el valor que le toque.
	$consulta->execute(array(':param1' => $usuarioID));

	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);

	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});


//******************************************************************************************************
//                                                Empresas
//******************************************************************************************************
//------------------------------------------------------------------------------------------------------
//Obtener las empresas
$app->get('/empresas', function() use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.
	$consulta = $db->prepare("select * from empresa");
	$consulta->execute();
	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);
	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});

//******************************************************************************************************
//                                                Turnos
//******************************************************************************************************
//------------------------------------------------------------------------------------------------------
//Obtener los turnos
$app->get('/turnos', function() use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.
	$consulta = $db->prepare("select * from turno_empresa");
	$consulta->execute();
	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);
	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});
//------------------------------------------------------------------------------------------------------
//Obtener turno por cedula
//Ejmplo http://localhost/api/turnos/302
$app->get('/turnos/:idusuario', function($usuarioID) use($db) {

	$consulta = $db->prepare("select * from turno_empresa where cedula=:param1 ");

	// En el execute es dónde asociamos el :param1 con el valor que le toque.
	$consulta->execute(array(':param1' => $usuarioID));

	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);

	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});


// Pedir turno en la API REST
$app->post('/turnos', function() use($db, $app) {
	// Para acceder a los datos recibidos del formulario
	$datosform = $app->request;

	// Los datos serán accesibles de esta forma:
	// $datosform->post('apellidos')
	// Preparamos la consulta de insert.
	$consulta = $db->prepare("insert into turno_empresa(empresa_id,nombre,cedula,turno,hora) 
					values (:empresa_id,:nombre,:cedula,:turno,:hora)");

	$estado = $consulta->execute(
		   array(
			  ':empresa_id' => $datosform->post('empresa_id'),
			  ':nombre' => $datosform->post('nombre'),
			  ':cedula' => $datosform->post('cedula'),
			  ':turno' => $datosform->post('turno'),
			  ':hora' => $datosform->post('hora')
		   )
	);
	if ($estado)
		echo json_encode(array('estado' => true, 'mensaje' => 'Datos insertados correctamente.'));
	else
		echo json_encode(array('estado' => false, 'mensaje' => 'Error en el registro, intente de nuevo.'));
});
//******************************************************************************************************
//                                                Alertas
//******************************************************************************************************

//------------------------------------------------------------------------------------------------------
//Obtener las alertas
$app->get('/alertas', function() use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.
	$consulta = $db->prepare("select * from alerta");
	$consulta->execute();
	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);
	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});

//******************************************************************************************************
//                                                PQR
//******************************************************************************************************
//------------------------------------------------------------------------------------------------------
// Alta de PQR en la API REST
$app->post('/pqr', function() use($db, $app) {
	// Para acceder a los datos recibidos del formulario
	$datosform = $app->request;

	// Los datos serán accesibles de esta forma:
	// $datosform->post('apellidos')
	// Preparamos la consulta de insert.

	$consulta = $db->prepare("insert into pqr(tipo_doc,numero,nombre,apellido,telefono,direccion,ciud_dpto,dir_not,ciud_dpto_not,correo_not,autorizacion,dir_pred,ciud_dpto_pred,ciud_depto_empresa,servicio,empresa,otra_emp,cuenta_emp,asunto,anexo,estado,codigo) 
					values (:tipo_doc,:numero,:nombre,:apellido,:telefono,:direccion,:ciud_dpto,:dir_not,:ciud_dpto_not,:correo_not,:autorizacion,:dir_pred,:ciud_dpto_pred,:ciud_depto_empresa,:servicio,:empresa,:otra_emp,:cuenta_emp,:asunto,:anexo,:estado,:codigo)");

	$estado = $consulta->execute(
		   array(
			  ':tipo_doc' => $datosform->post('tipo_doc'),
			  ':numero' => $datosform->post('numero'),
			  ':nombre' => $datosform->post('nombre'),
			  ':apellido' => $datosform->post('apellido'),
			  ':telefono' => $datosform->post('telefono'),
			  ':direccion' => $datosform->post('direccion'),
			  ':ciud_dpto' => $datosform->post('ciud_dpto'),
			  ':dir_not' => $datosform->post('dir_not'),
			  ':ciud_dpto_not' => $datosform->post('ciud_dpto_not'),
			  ':correo_not' => $datosform->post('correo_not'),
			  ':autorizacion' => $datosform->post('autorizacion'),
			  ':dir_pred' => $datosform->post('dir_pred'),
			  ':ciud_dpto_pred' => $datosform->post('ciud_dpto_pred'),
			  ':ciud_depto_empresa' => $datosform->post('ciud_depto_empresa'),
			  ':servicio' => $datosform->post('servicio'),
			  ':empresa' => $datosform->post('empresa'),
			  ':otra_emp' => $datosform->post('otra_emp'),
			  ':cuenta_emp' => $datosform->post('cuenta_emp'),
			  ':asunto' => $datosform->post('asunto'),
			  ':anexo' => $datosform->post('anexo'),
			  ':estado' => $datosform->post('estado'),
			  ':codigo' => $datosform->post('codigo')
		   )
	);
	if ($estado)
		echo json_encode(array('estado' => true, 'mensaje' => 'Datos insertados correctamente.'));
	else
		echo json_encode(array('estado' => false, 'mensaje' => 'Error en el registro, intente de nuevo.'));
});
//------------------------------------------------------------------------------------------------------
//Obtener las pqr
$app->get('/pqr', function() use($db) {
	// Si necesitamos acceder a alguna variable global en el framework
	// Tenemos que pasarla con use() en la cabecera de la función. Ejemplo: use($db)
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.
	$consulta = $db->prepare("select * from pqr");
	$consulta->execute();
	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);
	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});

//------------------------------------------------------------------------------------------------------
// Accedemos por get a /pqr/ pasando un id de usuario. 
// Por ejemplo /pqr/101
// Ruta /pqr/id
// Los parámetros en la url se definen con :parametro
// El valor del parámetro :idusuario se pasará a la función de callback como argumento
$app->get('/pqr/:idusuario', function($usuarioID) use($db) {

	$consulta = $db->prepare("select * from pqr where numero=:param1 or codigo=:param1");

	// En el execute es dónde asociamos el :param1 con el valor que le toque.
	$consulta->execute(array(':param1' => $usuarioID));

	// Almacenamos los resultados en un array asociativo.
	$resultados = $consulta->fetchAll(PDO::FETCH_ASSOC);

	// Devolvemos ese array asociativo como un string JSON.
	echo json_encode($resultados);
});



//******************************************************************************************************
//                                        Usuario
//******************************************************************************************************

// Alta de usuarios en la API REST
$app->post('/usuarios', function() use($db, $app) {
	// Para acceder a los datos recibidos del formulario
	$datosform = $app->request;

	// Los datos serán accesibles de esta forma:
	// $datosform->post('apellidos')
	// Preparamos la consulta de insert.
	$consulta = $db->prepare("insert into user(tipo_doc,numero_doc,nombres,apellidos,telefono,direccion,ciudad_depto,direccion_not,correo,autorizacion, pass,type) 
					values (:tipo_doc,:numero_doc,:nombres,:apellidos,:telefono,:direccion,:ciudad_depto, :direccion_not,:correo,:autorizacion,:pass,:type)");

	$estado = $consulta->execute(
		   array(
			  ':tipo_doc' => $datosform->post('tipo_doc'),
			  ':numero_doc' => $datosform->post('numero_doc'),
			  ':nombres' => $datosform->post('nombres'),
			  ':apellidos' => $datosform->post('apellidos'),
			  ':telefono' => $datosform->post('telefono'),
			  ':direccion' => $datosform->post('direccion'),
			  ':ciudad_depto' => $datosform->post('ciudad_depto'),
			  ':direccion_not' => $datosform->post('direccion_not'),
			  ':correo' => $datosform->post('correo'),
			  ':autorizacion' => $datosform->post('autorizacion'),
			  ':pass' => $datosform->post('pass'),
			  ':type' => $datosform->post('type')
		   )
	);
	if ($estado)
		echo json_encode(array('estado' => true, 'mensaje' => 'Datos insertados correctamente.'));
	else
		echo json_encode(array('estado' => false, 'mensaje' => 'Error en el registro, intente de nuevo.'));
});



//------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------
//API para crear turnos
// Alta de usuarios en la API REST
/*$app->post('/usuarios', function() use($db, $app) {
	// Para acceder a los datos recibidos del formulario
	$datosform = $app->request;

	// Los datos serán accesibles de esta forma:
	// $datosform->post('apellidos')
	// Preparamos la consulta de insert.
	$consulta = $db->prepare("insert into soporte_usuarios(idusuario,nombre,apellidos,email) 
					values (:idusuario,:nombre,:apellidos,:email)");

	$estado = $consulta->execute(
		   array(
			  ':idusuario' => $datosform->post('idusuario'),
			  ':nombre' => $datosform->post('nombre'),
			  ':apellidos' => $datosform->post('apellidos'),
			  ':email' => $datosform->post('email')
		   )
	);
	if ($estado)
		echo json_encode(array('estado' => true, 'mensaje' => 'Datos insertados correctamente.'));
	else
		echo json_encode(array('estado' => false, 'mensaje' => 'Error al insertar datos en la tabla.'));
});

*/
//------------------------------------------------------------------------------------------------------


// Programamos la ruta de borrado en la API REST (DELETE)
$app->delete('/usuarios/:idusuario', function($idusuario) use($db) {
	$consulta = $db->prepare("delete from soporte_usuarios where idusuario=:id");

	$consulta->execute(array(':id' => $idusuario));

	if ($consulta->rowCount() == 1)
		echo json_encode(array('estado' => true, 'mensaje' => 'El usuario ' . $idusuario . ' ha sido borrado correctamente.'));
	else
		echo json_encode(array('estado' => false, 'mensaje' => 'ERROR: ese registro no se ha encontrado en la tabla.'));
});


// Actualización de datos de usuario (PUT)
$app->put('/usuarios/:idusuario', function($idusuario) use($db, $app) {
	// Para acceder a los datos recibidos del formulario
	$datosform = $app->request;

	// Los datos serán accesibles de esta forma:
	// $datosform->post('apellidos')
	// Preparamos la consulta de update.
	$consulta = $db->prepare("update soporte_usuarios set nombre=:nombre, apellidos=:apellidos, email=:email 
							where idusuario=:idusuario");

	$estado = $consulta->execute(
		   array(
			  ':idusuario' => $idusuario,
			  ':nombre' => $datosform->post('nombre'),
			  ':apellidos' => $datosform->post('apellidos'),
			  ':email' => $datosform->post('email')
		   )
	);

	// Si se han modificado datos...
	if ($consulta->rowCount() == 1)
		echo json_encode(array('estado' => true, 'mensaje' => 'Datos actualizados correctamente.'));
	else
		echo json_encode(array('estado' => false, 'mensaje' => 'Error al actualizar datos, datos 
						no modificados o registro no encontrado.'));
});



//////////////////////////////////////////////////////////////////////////////////////////////////
// A PARTIR DE AQUÍ ES UN EJEMPLO DE USO DE SLIM FRAMEWORK PARA CREAR UNA APLICACIÓN.
//////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
//
// EJEMPLO DE USO DEL SLIM FRAMEWORK PARA GENERAR UNA APLICACIÓN.
// 
// 
//
// Ésto no formaría parte de la API REST. Ésto sería un ejemplo de aplicación
// que podemos generar con el framework Slim.
// Aquí se muestra un ejemplo de como se generaría una página utilizando vistas.
////////////////////////////////////////////////////////////////////////////
$app->get('/listadousuarios', function() use($db, $app) {
	// Va a devolver un objeto JSON con los datos de usuarios.
	// Preparamos la consulta a la tabla.
	$consulta = $db->prepare("select * from soporte_usuarios");
	// Ejecutamos la consulta (si fuera necesario se le pasan parámetros).
	$consulta->execute();

	// Ejemplo sencillo de paso de variables a una plantilla.
	/*
	  $app->render('miplantilla.php', array(
	  'name' => 'John',
	  'email' => '[email blocked]',
	  'active' => true
	  )
	  );
	 */

	// Desde dentro de la vista accederemos directamente a $resultados para gestionar su contenido.
	$app->render('listadousuarios.php', array(
	    'resultados' => $consulta->fetchAll(PDO::FETCH_ASSOC)
		   )
	);
});



// Cuando accedamos a /nuevousuario se mostrará un formulario de alta.
$app->get('/nuevousuario', function() use($app) {
	$app->render('nuevousuario.php');
})->name('altausuarios');


// Ruta que recibe los datos del formulario
$app->post('/nuevousuario', function() use($app, $db) {
	// Para acceder a los datos recibidos del formulario
	$datosform = $app->request;

	// Los datos serán accesibles de esta forma:
	// $datosform->post('apellidos')
	// Preparamos la consulta de insert.
	$consulta = $db->prepare("insert into soporte_usuarios(idusuario,nombre,apellidos,email)
				values (:idusuario,:nombre,:apellidos,:email)");

	$estado = $consulta->execute(
		   array(
			  ':idusuario' => $datosform->post('idusuario'),
			  ':nombre' => $datosform->post('nombre'),
			  ':apellidos' => $datosform->post('apellidos'),
			  ':email' => $datosform->post('email')
		   )
	);

	if ($estado)
		$app->flash('message', 'Usuario insertado correctamente.');
	else
		$app->flash('error', 'Se ha producido un error al guardar datos.');

	// Redireccionamos al formulario original para mostrar 
	// los mensajes Flash.,
	$app->redirect('nuevousuario');

	// Otra forma de hacerlo es:
	// $app->redirect($app->urlFor('altausuarios'));
});



// Otro ejemplo de aplicación en:
// http://coenraets.org/blog/2011/12/restful-services-with-jquery-php-and-the-slim-framework/
///////////////////////////////////////////////////////////////////////////////////////////////////////
// Al final de la aplicación terminamos con $app->run();
///////////////////////////////////////////////////////////////////////////////////////////////////////

$app->run();
?>